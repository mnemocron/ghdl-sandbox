# cos and sin LUT

Currently **NO** compression (half wave / quarter wave) is supported.

